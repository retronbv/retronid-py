# retronid
![retronid branding](/retronid/branding.png)

A short unique id.

```py
import retronid
print(retronid.generate())
```
# retronid
![retronid branding](https://raw.githubusercontent.com/retronbv/retronid-py/master/retronid/branding.png)

A short unique id.

```py
import retronid
print(retronid.generate())
```